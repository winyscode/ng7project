import { Component, OnInit } from '@angular/core';
import { PaymentService } from '../shared/payment/payment.service';
import { HttpErrorResponse } from '@angular/common/http';

@Component({
  selector: 'app-paymentlist',
  templateUrl: './paymentlist.component.html',
  styleUrls: ['./paymentlist.component.css']
})
export class PaymentlistComponent implements OnInit {
private payments: string [];
  constructor(private paymentService : PaymentService ) { }

  ngOnInit() {
    this.paymentService.getAll().subscribe(
      data => {
        this.payments = data as string [];	 // FILL THE ARRAY WITH DATA.
        //console.log(this.payments[1]);
      },
      (err: HttpErrorResponse) => {
        console.log (err.message);
      }
    );
  }

}
