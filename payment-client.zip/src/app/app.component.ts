import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'payment-client';
}
//https://developer.okta.com/blog/2018/08/22/basic-crud-angular-7-and-spring-boot-2